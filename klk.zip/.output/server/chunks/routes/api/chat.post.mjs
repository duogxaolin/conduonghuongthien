import { d as defineEventHandler, r as readBody, s as setHeader, c as createError, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const SYSTEM_PROMPT = `B\u1EA1n l\xE0 "Tr\u1EE3 l\xFD \u1EA3o H\u01B0\u1EDBng Thi\u1EC7n" - Chuy\xEAn gia t\u01B0 v\u1EA5n ph\xE1p l\xFD v\xE0 t\xE1i h\xF2a nh\u1EADp c\u1ED9ng \u0111\u1ED3ng thu\u1ED9c C\u1EE5c C\u1EA3nh s\xE1t qu\u1EA3n l\xFD t\u1EA1m gi\u1EEF, t\u1EA1m giam v\xE0 thi h\xE0nh \xE1n h\xECnh s\u1EF1 t\u1EA1i c\u1ED9ng \u0111\u1ED3ng (C11 - B\u1ED9 C\xF4ng an Vi\u1EC7t Nam).

M\u1EE4C TI\xCAU V\xC0 PH\u1EA0M VI H\u1ED6 TR\u1EE2 CH\xCDNH:
1. **Ch\xEDnh s\xE1ch T\xEDn d\u1EE5ng \u01B0u \u0111\xE3i (Quy\u1EBFt \u0111\u1ECBnh 22/2023/Q\u0110-TTg c\u1EE7a Th\u1EE7 t\u01B0\u1EDBng Ch\xEDnh ph\u1EE7)**:
   - C\xE1 nh\xE2n ch\u1EA5p h\xE0nh xong \xE1n ph\u1EA1t t\xF9 \u0111\u01B0\u1EE3c vay t\u1ED1i \u0111a 100 tri\u1EC7u \u0111\u1ED3ng \u0111\u1EC3 s\u1EA3n xu\u1EA5t, kinh doanh, t\u1EA1o vi\u1EC7c l\xE0m t\u1EA1i Ng\xE2n h\xE0ng Ch\xEDnh s\xE1ch X\xE3 h\u1ED9i.
   - Vay v\u1ED1n h\u1ECDc ngh\u1EC1 t\u1ED1i \u0111a 4 tri\u1EC7u \u0111\u1ED3ng/th\xE1ng/ng\u01B0\u1EDDi.
   - Th\u1EA9m \u0111\u1ECBnh qua UBND c\u1EA5p x\xE3 v\xE0 H\u1ED9i \u0111o\xE0n th\u1EC3 (Ph\u1EE5 n\u1EEF, N\xF4ng d\xE2n, C\u1EF1u chi\u1EBFn binh, \u0110o\xE0n thanh ni\xEAn...).

2. **C\xE1c ch\xEDnh s\xE1ch H\u1ED7 tr\u1EE3 T\xE1i h\xF2a nh\u1EADp (Ngh\u1ECB \u0111\u1ECBnh 49/2020/N\u0110-CP)**:
   - \u0110\xE0o t\u1EA1o ngh\u1EC1 mi\u1EC5n ph\xED/gi\u1EA3m chi ph\xED t\u1EA1i c\xE1c trung t\xE2m d\u1EA1y ngh\u1EC1 \u0111\u1ECBa ph\u01B0\u01A1ng.
   - Gi\u1EDBi thi\u1EC7u vi\u1EC7c l\xE0m qua Trung t\xE2m d\u1ECBch v\u1EE5 vi\u1EC7c l\xE0m S\u1EDF L\u0110-TB&XH v\xE0 c\xE1c doanh nghi\u1EC7p li\xEAn k\u1EBFt.
   - H\u1ED7 tr\u1EE3 l\xE0m th\u1EE7 t\u1EE5c c\u1EA5p C\u0103n c\u01B0\u1EDBc c\xF4ng d\xE2n, \u0111\u0103ng k\xFD th\u01B0\u1EDDng tr\xFA/t\u1EA1m tr\xFA.

3. **Th\u1EE7 t\u1EE5c Ph\xE1p l\xFD & X\xF3a \xE1n t\xEDch (B\u1ED9 lu\u1EADt H\xECnh s\u1EF1 & B\u1ED9 lu\u1EADt T\u1ED1 t\u1EE5ng h\xECnh s\u1EF1)**:
   - H\u01B0\u1EDBng d\u1EABn \u0111i\u1EC1u ki\u1EC7n \u0111\u01B0\u01A1ng nhi\xEAn x\xF3a \xE1n t\xEDch khi h\u1EBFt th\u1EDDi gian th\u1EED th\xE1ch v\xE0 thi h\xE0nh xong c\xE1c b\u1EA3n \xE1n d\xE2n s\u1EF1/\xE1n ph\xED.
   - H\u01B0\u1EDBng d\u1EABn h\u1ED3 s\u01A1 xin c\u1EA5p Phi\u1EBFu l\xFD l\u1ECBch t\u01B0 ph\xE1p s\u1ED1 2 t\u1EA1i S\u1EDF T\u01B0 ph\xE1p t\u1EC9nh/th\xE0nh ph\u1ED1 ho\u1EB7c C\u1ED5ng D\u1ECBch v\u1EE5 c\xF4ng Qu\u1ED1c gia.

4. **T\u01B0 v\u1EA5n \u0110\u1ED9ng vi\xEAn T\xE2m l\xFD & Nh\xE2n v\u0103n**:
   - L\u1EAFng nghe, \u0111\u1ED9ng vi\xEAn tinh th\u1EA7n, gi\xFAp ng\u01B0\u1EDDi ch\u1EA5p h\xE0nh xong \xE1n ph\u1EA1t t\xF9 v\u01B0\u1EE3t qua m\u1EB7c c\u1EA3m t\u1EF1 tin, h\u01B0\u1EDBng t\u1EDBi l\u1ED1i s\u1ED1ng l\xE0nh m\u1EA1nh, l\u01B0\u01A1ng thi\u1EC7n.

5. **Th\xF4ng tin \u0110\u01B0\u1EDDng d\xE2y n\xF3ng**:
   - Hotline h\u1ED7 tr\u1EE3 24/7 c\u1EE7a \u0110\u1EC1 \xE1n: **0903.480.985**.

PHONG C\xC1CH V\xC0 QUY T\u1EAEC \u1EE8NG X\u1EEC:
- \u0110\u1EA3m b\u1EA3o t\xEDnh ch\xEDnh x\xE1c 100% v\u1EC1 m\u1EB7t ph\xE1p lu\u1EADt Vi\u1EC7t Nam.
- Ng\xF4n t\u1EEB trang tr\u1ECDng nh\u01B0ng \u1EA5m \xE1p, nh\xE2n v\u0103n, th\u1EA5u hi\u1EC3u, kh\xEDch l\u1EC7.
- Tr\xECnh b\xE0y ng\u1EAFn g\u1ECDn, d\u1EC5 hi\u1EC3u, s\u1EED d\u1EE5ng danh s\xE1ch g\u1EA1ch \u0111\u1EA7u d\xF2ng r\xF5 r\xE0ng.
- N\u1EBFu c\xE2u h\u1ECFi qu\xE1 ph\u1EE9c t\u1EA1p ho\u1EB7c v\u01B0\u1EE3t qu\xE1 th\u1EA9m quy\u1EC1n t\u01B0 v\u1EA5n tr\u1EF1c tuy\u1EBFn, nh\u1EB9 nh\xE0ng khuy\xEAn ng\u01B0\u1EDDi d\xE2n li\xEAn h\u1EC7 Hotline 0903.480.985 ho\u1EB7c C\xF4ng an x\xE3/ph\u01B0\u1EDDng g\u1EA7n nh\u1EA5t.`;
const chat_post = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig();
  const body = await readBody(event);
  const userMessages = body.messages || [];
  const formattedMessages = [
    { role: "system", content: SYSTEM_PROMPT },
    ...userMessages.map((msg) => ({
      role: msg.sender === "user" ? "user" : "assistant",
      content: msg.text
    }))
  ];
  const apiKey = config.aiApiKey;
  const baseUrl = config.aiBaseUrl.replace(/\/$/, "");
  const model = config.aiModel || "gpt-4o-mini";
  if (!apiKey || apiKey.trim() === "" || apiKey === "your_api_key_here") {
    const lastUserMsg = ((_a = [...userMessages].reverse().find((m) => m.sender === "user")) == null ? void 0 : _a.text) || "";
    const cleanText = lastUserMsg.toLowerCase();
    let reply = "Xin ch\xE0o! Hi\u1EC7n t\u1EA1i h\u1EC7 th\u1ED1ng \u0111ang ch\u1EA1y \u1EDF ch\u1EBF \u0111\u1ED9 D\u1EEF li\u1EC7u Ph\xE1p l\xFD N\u1ED9i b\u1ED9 C11. (\u0110\u1EC3 k\xEDch ho\u1EA1t AI Real-time, vui l\xF2ng b\u1ED5 sung AI_API_KEY trong file .env).";
    if (cleanText.includes("vay") || cleanText.includes("v\u1ED1n") || cleanText.includes("ti\u1EC1n")) {
      reply = "Theo Quy\u1EBFt \u0111\u1ECBnh 22/2023/Q\u0110-TTg c\u1EE7a Th\u1EE7 t\u01B0\u1EDBng Ch\xEDnh ph\u1EE7, ng\u01B0\u1EDDi ch\u1EA5p h\xE0nh xong \xE1n ph\u1EA1t t\xF9 \u0111\u01B0\u1EE3c Ng\xE2n h\xE0ng Ch\xEDnh s\xE1ch X\xE3 h\u1ED9i cho vay \u01B0u \u0111\xE3i t\u1ED1i \u0111a 100 tri\u1EC7u \u0111\u1ED3ng \u0111\u1EC3 l\xE0m kinh t\u1EBF, s\u1EA3n xu\u1EA5t kinh doanh v\xE0 t\u1ED1i \u0111a 4 tri\u1EC7u \u0111\u1ED3ng/th\xE1ng \u0111\u1EC3 h\u1ECDc ngh\u1EC1.\n\n\u0110\u01A1n \u0111\u1EC1 ngh\u1ECB vay v\u1ED1n c\u1EA7n c\xF3 x\xE1c nh\u1EADn c\u1EE7a UBND c\u1EA5p x\xE3 n\u01A1i c\u01B0 tr\xFA.";
    } else if (cleanText.includes("x\xF3a") || cleanText.includes("\xE1n t\xEDch") || cleanText.includes("l\xFD l\u1ECBch")) {
      reply = "Th\u1EE7 t\u1EE5c x\xF3a \xE1n t\xEDch \u0111\u01B0\u1EE3c quy \u0111\u1ECBnh chi ti\u1EBFt t\u1EA1i B\u1ED9 lu\u1EADt H\xECnh s\u1EF1. Khi h\u1EBFt th\u1EDDi h\u1EA1n th\u1EED th\xE1ch v\xE0 thi h\xE0nh xong h\xECnh ph\u1EA1t b\u1ED5 sung (\xE1n ph\xED, b\u1ED3i th\u01B0\u1EDDng d\xE2n s\u1EF1), b\u1EA1n n\u1ED9p h\u1ED3 s\u01A1 xin c\u1EA5p Phi\u1EBFu l\xFD l\u1ECBch t\u01B0 ph\xE1p s\u1ED1 2 t\u1EA1i S\u1EDF T\u01B0 ph\xE1p \u0111\u1ECBa ph\u01B0\u01A1ng \u0111\u1EC3 l\xE0m c\u0103n c\u1EE9 x\xE1c nh\u1EADn x\xF3a \xE1n t\xEDch.";
    } else if (cleanText.includes("ngh\u1EC1") || cleanText.includes("h\u1ECDc") || cleanText.includes("vi\u1EC7c l\xE0m")) {
      reply = "Theo Ngh\u1ECB \u0111\u1ECBnh 49/2020/N\u0110-CP, ng\u01B0\u1EDDi ho\xE0n l\u01B0\u01A1ng \u0111\u01B0\u1EE3c ch\xEDnh quy\u1EC1n \u0111\u1ECBa ph\u01B0\u01A1ng t\u01B0 v\u1EA5n h\u01B0\u1EDBng nghi\u1EC7p, \u0111\xE0o t\u1EA1o ngh\u1EC1 mi\u1EC5n ph\xED v\xE0 h\u1ED7 tr\u1EE3 bao ti\xEAu vi\u1EC7c l\xE0m th\xF4ng qua Trung t\xE2m d\u1ECBch v\u1EE5 vi\u1EC7c l\xE0m c\u1EE7a S\u1EDF L\u0110-TB&XH.";
    } else if (cleanText.includes("hotline") || cleanText.includes("li\xEAn h\u1EC7") || cleanText.includes("\u0111i\u1EC7n tho\u1EA1i")) {
      reply = "\u0110\u01B0\u1EDDng d\xE2y n\xF3ng h\u1ED7 tr\u1EE3 24/7 c\u1EE7a \u0110\u1EC1 \xE1n t\xE1i h\xF2a nh\u1EADp c\u1ED9ng \u0111\u1ED3ng C11 - B\u1ED9 C\xF4ng an l\xE0: **0903.480.985**.";
    }
    setHeader(event, "Content-Type", "text/event-stream");
    setHeader(event, "Cache-Control", "no-cache");
    setHeader(event, "Connection", "keep-alive");
    return new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        for (let i = 0; i < reply.length; i += 3) {
          const chunk = reply.slice(i, i + 3);
          const data = JSON.stringify({ choices: [{ delta: { content: chunk } }] });
          controller.enqueue(encoder.encode(`data: ${data}

`));
          await new Promise((resolve) => setTimeout(resolve, 20));
        }
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      }
    });
  }
  try {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        messages: formattedMessages,
        stream: true,
        temperature: 0.7,
        max_tokens: 1e3
      })
    });
    if (!response.ok) {
      const errText = await response.text();
      console.error("AI Provider Error:", errText);
      throw createError({ statusCode: response.status, statusMessage: `AI Provider Error: ${errText}` });
    }
    setHeader(event, "Content-Type", "text/event-stream");
    setHeader(event, "Cache-Control", "no-cache");
    setHeader(event, "Connection", "keep-alive");
    return response.body;
  } catch (error) {
    console.error("AI Proxy Error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: error.message || "L\u1ED7i k\u1EBFt n\u1ED1i t\u1EDBi AI Service"
    });
  }
});

export { chat_post as default };
//# sourceMappingURL=chat.post.mjs.map
