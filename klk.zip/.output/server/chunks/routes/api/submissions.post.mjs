import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import { promises } from 'node:fs';
import path from 'node:path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'node:url';

const DATA_DIR = path.resolve(process.cwd(), "server/data");
const DATA_FILE = path.join(DATA_DIR, "submissions.json");
async function ensureStore() {
  await promises.mkdir(DATA_DIR, { recursive: true });
  try {
    await promises.access(DATA_FILE);
  } catch {
    await promises.writeFile(DATA_FILE, "[]", "utf-8");
  }
}
async function appendRecord(record) {
  await ensureStore();
  const raw = await promises.readFile(DATA_FILE, "utf-8").catch(() => "[]");
  let arr = [];
  try {
    arr = JSON.parse(raw || "[]");
  } catch {
    arr = [];
  }
  arr.push(record);
  await promises.writeFile(DATA_FILE, JSON.stringify(arr, null, 2), "utf-8");
}
const PHONE_RE = /^[0-9+()\-\s.]{7,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const submissions_post = defineEventHandler(async (event) => {
  const body = await readBody(event).catch(() => ({}));
  const type = (body == null ? void 0 : body.type) === "contact" ? "contact" : "support";
  const name = String((body == null ? void 0 : body.name) || "").trim();
  const phone = String((body == null ? void 0 : body.phone) || "").trim();
  const email = String((body == null ? void 0 : body.email) || "").trim();
  const city = String((body == null ? void 0 : body.city) || "").trim();
  const address = String((body == null ? void 0 : body.address) || "").trim();
  const message = String((body == null ? void 0 : body.message) || "").trim();
  if (!name || name.length < 2) {
    throw createError({ statusCode: 400, statusMessage: "Vui l\xF2ng nh\u1EADp h\u1ECD t\xEAn h\u1EE3p l\u1EC7." });
  }
  if (!phone || !PHONE_RE.test(phone)) {
    throw createError({ statusCode: 400, statusMessage: "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i kh\xF4ng h\u1EE3p l\u1EC7." });
  }
  if (email && !EMAIL_RE.test(email)) {
    throw createError({ statusCode: 400, statusMessage: "Email kh\xF4ng h\u1EE3p l\u1EC7." });
  }
  if (!message || message.length < 5) {
    throw createError({ statusCode: 400, statusMessage: "N\u1ED9i dung tr\u1EE3 gi\xFAp qu\xE1 ng\u1EAFn." });
  }
  const record = {
    id: Date.now(),
    type,
    name,
    phone,
    email: email || null,
    city: city || null,
    address: address || null,
    message,
    submittedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await appendRecord(record);
  return { ok: true, id: record.id };
});

export { submissions_post as default };
//# sourceMappingURL=submissions.post.mjs.map
