const interopDefault = r => r.default || r || [];
const styles = {
  "pages/giai-dap-phap-luat/index.vue": () => import('../build/index-styles.BohrJRyb.mjs').then(interopDefault),
  "pages/ban-tin/index.vue": () => import('../build/index-styles-2.CwxUObYZ.mjs').then(interopDefault),
  "pages/ban-tin/tin-dia-phuong.vue": () => import('../build/tin-dia-phuong-styles.DTfeTjxu.mjs').then(interopDefault),
  "pages/ban-tin/tin-hoat-dong.vue": () => import('../build/tin-hoat-dong-styles.C9Ij5xnJ.mjs').then(interopDefault),
  "pages/mohinhtaihoanhap/index.vue": () => import('../build/index-styles-3.BbR88ub8.mjs').then(interopDefault),
  "pages/lien-he.vue": () => import('../build/lien-he-styles.Bh3A3tA9.mjs').then(interopDefault),
  "pages/ban-tin/tin-noi-bat.vue": () => import('../build/tin-noi-bat-styles.DpKY4RmS.mjs').then(interopDefault),
  "pages/van-ban/index.vue": () => import('../build/index-styles-4.8xF6Corv.mjs').then(interopDefault),
  "pages/tamguongtieubieu/index.vue": () => import('../build/index-styles-5.3sU_M7bf.mjs').then(interopDefault),
  "pages/gioi-thieu.vue": () => import('../build/gioi-thieu-styles.Gn68WpPs.mjs').then(interopDefault),
  "pages/mohinhtaihoanhap/[id].vue": () => import('../build/_id_-styles.UzP5oxEp.mjs').then(interopDefault),
  "pages/ban-tin/[id].vue": () => import('../build/_id_-styles-2.DLL0Wbul.mjs').then(interopDefault),
  "pages/tamguongtieubieu/[id].vue": () => import('../build/_id_-styles-3.Dz1dOnt-.mjs').then(interopDefault),
  "pages/index.vue": () => import('../build/index-styles-6.Bg00eERS.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.CMKixN0I.mjs').then(interopDefault),
  "../node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.ClZS4Tbf.mjs').then(interopDefault),
  "layouts/default.vue": () => import('../build/default-styles.DBzP4g9k.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
